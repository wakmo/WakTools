/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.wakkir.files;

import com.wakkir.utils.FileUtils;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;

/**
 *
 * @author wakkir
 */
public class ReadFiles
{
    static String filepath=".\\data";

    public static byte[] readFully(InputStream stream) throws IOException
    {
        byte[] buffer = new byte[8192];
        ByteArrayOutputStream baos = new ByteArrayOutputStream();

        int bytesRead;
        while ((bytesRead = stream.read(buffer)) != -1)
        {
            baos.write(buffer, 0, bytesRead);
        }
        return baos.toByteArray();
    }

    public static byte[] loadFile(String sourcePath) throws IOException
    {
        InputStream inputStream = null;
        try
        {
            inputStream = new FileInputStream(sourcePath);
            return readFully(inputStream);
        }
        finally
        {
            if (inputStream != null)
            {
                inputStream.close();
            }
        }
    }
    
    public static void loadFileToBase64(String sourcePath) throws IOException
    {
        InputStream inputStream = null;
        byte[] bytes64bytes=null;
        byte[] bytesbytes=null;        
        try
        {
            inputStream = new FileInputStream(sourcePath);
            
            bytesbytes=IOUtils.toByteArray(inputStream);
            //content = new String(bytesbytes);
            System.out.println(bytesbytes.length);
            boolean b1=FileUtils.saveFile(bytesbytes, filepath, "test1_1before_encodeToBase64.pdf");
            
            bytes64bytes = Base64.encodeBase64(bytesbytes);
            //content64 = new String(bytes64bytes);
            System.out.println(bytes64bytes.length);
            boolean b2=FileUtils.saveFile(bytes64bytes, filepath, "test1_2after_encodeToBase64.pdf");            
            
        }
        finally
        {
            if (inputStream != null)
            {
                inputStream.close();
            }
        }
    }
    
    public static void loadBase64File(String sourcePath) throws IOException
    {
        InputStream inputStream = null;
        byte[] bytes64bytes=null;
        byte[] bytesbytes=null;        
        try
        {
            inputStream = new FileInputStream(sourcePath);
            
            bytesbytes=IOUtils.toByteArray(inputStream);
            //content = new String(bytesbytes);
            System.out.println(bytesbytes.length);
            boolean b1=FileUtils.saveFile(bytesbytes, filepath, "test2_1before_decodeFromBase64.pdf");
            
            bytes64bytes = Base64.decodeBase64(bytesbytes);
            //content64 = new String(bytes64bytes);
            System.out.println(bytes64bytes.length);
            boolean b2=FileUtils.saveFile(bytes64bytes, filepath, "test2_2after_decodeFromBase64.pdf");            
            
        }
        finally
        {
            if (inputStream != null)
            {
                inputStream.close();
            }
        }
    }

    public static void main(String[] args)
    {

        try
        {             
            loadFileToBase64(filepath+"\\000015.pdf");
            loadBase64File(filepath+"\\test1_2after_encodeToBase64.pdf");
       
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
